var MusicPlayer = (function() {
    function MusicPlayer() {
        this.audio = null;
        this.isPlaying = false;
        this.currentSongIndex = 0;
        this.lyrics = [];
        this.currentLyricIndex = -1;
        this.desktopLyricsEnabled = true;
        
        this.musicList = [
                     {
                id: 'mang',
                title: '茫 - 群星',
                url: 'http://note.youdao.com/yws/api/personal/file/WEBf4e96e6012b361ff92b7fb1f4b5323d0?method=download&inline=true&shareKey=339ddbc23cc95a244a8feb25891cc095',
                lrcUrl: 'https://note.youdao.com/yws/api/personal/file/WEBe358f83fa7ee2258104dd9d2ec30c217?method=download&inline=true&shareKey=3deaa21b712e17895557da822c2a151b'
            },
               {
                id: 'cishengbuhuan',
                title: '此生不换 - DJ降调',
                url: 'https://note.youdao.com/yws/api/personal/file/WEB01f0aecd49e612afcd4a4a4d4e26f60a?method=download&inline=true&shareKey=2a134f98a4f5da480e94c3da309cbc33',
                lrcUrl: 'https://note.youdao.com/yws/api/personal/file/WEB5f974d67cf6cc41847f7fe27e079beb3?method=download&inline=true&shareKey=1fd36ece2aaa251f84e006e631b7d12d'
            },
            {
                id: 'yichengshanlu',
                title: '毛毛 - 一程山路',
                url: 'https://note.youdao.com/yws/api/personal/file/WEB08eae1417bb953cc4a65a4b56f549d3a?method=download&inline=true&shareKey=07388e5e1b3ca4787da9fc5f8c39ce8a',
                lrcUrl: 'https://note.youdao.com/yws/api/personal/file/WEB53bf55af8306cce258de575f61d65b56?method=download&inline=true&shareKey=c12b4936900e0eef69c9309abc1c1bdb'
            },
            {
                id: 'fengchuitou',
                title: '群星 - 风吹透',
                url: 'https://note.youdao.com/yws/api/personal/file/WEB42fef8283e691254a8993032d6216ebe?method=download&inline=true&shareKey=8e55342d374d568b9657128ba9f16212',
                lrcUrl: './lrc/fengchuitou.lrc'
            },
            {
                id: 'shikong',
                title: '群星 - 失控',
                url: 'https://note.youdao.com/yws/api/personal/file/00234c8c38ecd64c6019d46c9b8f153b?method=download&inline=true&shareKey=98669ad7c421a1f6d7e59350f4ad943c',
                lrcUrl: './lrc/shikong.lrc'
            },
            {
                id: 'yujian',
                title: '孙燕姿 - 遇见',
                url: 'https://note.youdao.com/yws/api/personal/file/1f3ec446fd52ecd683be5c509aebf58d?method=download&inline=true&shareKey=fc9eac5d25590b1c61a9d8a9450d653a',
                lrcUrl: './lrc/yujian.lrc'
            },
            {
                id: 'geinigeiwo',
                title: '毛不易 - 给你给我',
                url: 'https://note.youdao.com/yws/api/personal/file/e9255f74a03034e6194aad0a8d1f277e?method=download&inline=true&shareKey=be61f4113153eade2911bf6fe6891931',
                lrcUrl: './lrc/gngwo.lrc'
            },
            {
                id: 'shaonianzhongguoshuo',
                title: '张杰 - 少年中国说',
                url: 'https://note.youdao.com/yws/api/personal/file/19803c2bfda5cfd06df07147ee8ece54?method=download&inline=true&shareKey=4ab84312ba36407a167125812538a768',
                lrcUrl: './lrc/china_say.lrc'
            }
        ];
        
        this.init();
    }
    
    MusicPlayer.prototype.init = function() {
        this.createAudio();
        this.bindEvents();
        this.updateMusicList();
        this.loadSong(0);
    };
    
    MusicPlayer.prototype.createAudio = function() {
        this.audio = new Audio();
        this.audio.volume = 0.5;
        
        var self = this;
        
        this.audio.addEventListener('timeupdate', function() {
            self.updateProgress();
            self.updateLyrics();
        });
        
        this.audio.addEventListener('ended', function() {
            self.nextSong();
        });
        
        this.audio.addEventListener('play', function() {
            self.isPlaying = true;
            self.updatePlayButton();
            $('.song-cover').addClass('playing');
        });
        
        this.audio.addEventListener('pause', function() {
            self.isPlaying = false;
            self.updatePlayButton();
            $('.song-cover').removeClass('playing');
        });
        
        this.audio.addEventListener('loadedmetadata', function() {
            self.updateDuration();
        });
    };
    
    MusicPlayer.prototype.bindEvents = function() {
        var self = this;
        
        $('#playPauseBtn').off('click').on('click', function() {
            self.togglePlay();
        });
        
        $('#prevBtn').off('click').on('click', function() {
            self.prevSong();
        });
        
        $('#nextBtn').off('click').on('click', function() {
            self.nextSong();
        });
        
        $('.progress-bar-container').off('click').on('click', function(e) {
            var rect = this.getBoundingClientRect();
            var percent = (e.clientX - rect.left) / rect.width;
            self.audio.currentTime = percent * self.audio.duration;
        });
        
        $('.volume-slider').off('input').on('input', function() {
            self.audio.volume = this.value;
        });
        
        $('#togglePlaylistBtn').off('click').on('click', function() {
            var $playlistSection = $('.music-list-section');
            var $btn = $(this);
            $playlistSection.toggleClass('hidden');
            if ($playlistSection.hasClass('hidden')) {
                $btn.text('显示播放列表');
            } else {
                $btn.text('隐藏播放列表');
            }
        });

        $('#desktopLyricsBtn').off('click').on('click', function() {
            self.toggleDesktopLyrics();
            var $btn = $(this);
            if (self.desktopLyricsEnabled) {
                $btn.addClass('active');
                $btn.text('🖥️ 关闭桌面歌词');
            } else {
                $btn.removeClass('active');
                $btn.text('🖥️ 桌面歌词');
            }
        });

        var $desktopLyricsBtn = $('#desktopLyricsBtn');
        if (this.desktopLyricsEnabled) {
            $desktopLyricsBtn.addClass('active');
            $desktopLyricsBtn.text('🖥️ 关闭桌面歌词');
        }
    };
    
    MusicPlayer.prototype.loadSong = function(index) {
        if (index < 0 || index >= this.musicList.length) return;
        
        this.currentSongIndex = index;
        var song = this.musicList[index];
        
        this.audio.src = song.url;
        this.audio.load();
        
        $('.song-title-display').text(song.title);
        this.updateMusicList();
        
        if (song.lrcUrl) {
            this.loadLyrics(song.lrcUrl);
        } else {
            this.clearLyrics();
        }
    };
    
    MusicPlayer.prototype.loadLyrics = function(lrcUrl) {
        var self = this;
        this.lyrics = [];
        
        $.get(lrcUrl).done(function(data) {
            self.parseLyrics(data);
        }).fail(function() {
            self.clearLyrics();
        });
    };
    
    MusicPlayer.prototype.parseLyrics = function(lrcText) {
        this.lyrics = [];
        var lines = lrcText.split('\n');
        
        var standardTimeRegex = /\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)/;
        
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim();
            if (!line) continue;
            
            var match = line.match(standardTimeRegex);
            if (match) {
                var minutes = parseInt(match[1]);
                var seconds = parseInt(match[2]);
                var milliseconds = parseInt(match[3]);
                var time = minutes * 60 + seconds + milliseconds / 1000;
                var text = match[4] ? match[4].trim() : '';
                
                if (text) {
                    this.lyrics.push({ time: time, text: text });
                }
            }
        }
        
        if (this.lyrics.length === 0) {
            var charTimeRegex = /\[(\d{2}):(\d{2})\.(\d{3})\]([^\[]*)/g;
            
            for (var i = 0; i < lines.length; i++) {
                var line = lines[i];
                var fullText = '';
                var lastTime = null;
                var match;
                
                charTimeRegex.lastIndex = 0;
                while ((match = charTimeRegex.exec(line)) !== null) {
                    var minutes = parseInt(match[1]);
                    var seconds = parseInt(match[2]);
                    var milliseconds = parseInt(match[3]);
                    var time = minutes * 60 + seconds + milliseconds / 1000;
                    var char = match[4] || '';
                    
                    fullText += char;
                    lastTime = time;
                }
                
                if (fullText.trim() && lastTime !== null) {
                    this.lyrics.push({ time: lastTime, text: fullText });
                }
            }
        }
        
        this.lyrics.sort(function(a, b) { return a.time - b.time; });
        this.displayLyrics();
        
        if (this.audio) {
            var self = this;
            setTimeout(function() {
                self.updateLyrics();
            }, 100);
        }
    };
    
    MusicPlayer.prototype.displayLyrics = function() {
        var container = $('.lyrics-display');
        container.empty();
        
        if (this.lyrics.length === 0) {
            container.append('<div class="lyrics-line">暂无歌词</div>');
            return;
        }
        
        for (var i = 0; i < this.lyrics.length; i++) {
            container.append('<div class="lyrics-line" data-index="' + i + '">' + this.lyrics[i].text + '</div>');
        }
    };
    
    MusicPlayer.prototype.updateLyrics = function() {
        if (this.lyrics.length === 0) return;
        
        var currentTime = this.audio.currentTime;
        var newIndex = -1;
        
        for (var i = 0; i < this.lyrics.length; i++) {
            if (i === this.lyrics.length - 1 || 
                (this.lyrics[i].time <= currentTime && this.lyrics[i + 1].time > currentTime)) {
                newIndex = i;
                break;
            }
        }
        
        if (newIndex >= 0) {
            var shouldUpdateHighlight = newIndex !== this.currentLyricIndex;
            
            if (shouldUpdateHighlight) {
                this.currentLyricIndex = newIndex;
                $('.lyrics-line').removeClass('active');
                $('.lyrics-line[data-index="' + newIndex + '"]').addClass('active');
                this.updateDesktopLyrics();
            }
            
            var container = $('.lyrics-display');
            var activeLine = $('.lyrics-line.active');
            
            if (container.length && activeLine.length && container[0].clientHeight > 0) {
                var lineOffsetTop = activeLine[0].offsetTop;
                var containerHeight = container[0].clientHeight;
                var lineHeight = activeLine[0].offsetHeight;
                var currentScrollTop = container[0].scrollTop;
                
                var isVisible = (lineOffsetTop >= currentScrollTop && 
                               lineOffsetTop + lineHeight <= currentScrollTop + containerHeight);
                
                if (!isVisible || shouldUpdateHighlight) {
                    var scrollTop = lineOffsetTop - containerHeight / 2 + lineHeight / 2;
                    scrollTop = Math.max(0, Math.min(scrollTop, container[0].scrollHeight - containerHeight));
                    container[0].scrollTop = scrollTop;
                }
            }
        }
    };
    
    MusicPlayer.prototype.clearLyrics = function() {
        this.lyrics = [];
        this.currentLyricIndex = -1;
        $('.lyrics-display').html('<div class="lyrics-line">暂无歌词</div>');
    };
    
    MusicPlayer.prototype.updateProgress = function() {
        if (this.audio.duration) {
            var progress = (this.audio.currentTime / this.audio.duration) * 100;
            $('.progress-bar-fill').css('width', progress + '%');
            
            var currentMin = Math.floor(this.audio.currentTime / 60);
            var currentSec = Math.floor(this.audio.currentTime % 60);
            $('.current-time').text(
                (currentMin < 10 ? '0' : '') + currentMin + ':' + 
                (currentSec < 10 ? '0' : '') + currentSec
            );
        }
    };
    
    MusicPlayer.prototype.updateDuration = function() {
        var durationMin = Math.floor(this.audio.duration / 60);
        var durationSec = Math.floor(this.audio.duration % 60);
        $('.duration-time').text(
            (durationMin < 10 ? '0' : '') + durationMin + ':' + 
            (durationSec < 10 ? '0' : '') + durationSec
        );
    };
    
    MusicPlayer.prototype.updatePlayButton = function() {
        var btn = $('#playPauseBtn');
        if (this.isPlaying) {
            btn.html('⏸');
        } else {
            btn.html('▶');
        }
    };
    
    MusicPlayer.prototype.updateMusicList = function() {
        var container = $('.music-list');
        container.empty();
        
        for (var i = 0; i < this.musicList.length; i++) {
            var song = this.musicList[i];
            var isActive = i === this.currentSongIndex;
            var item = '<li class="music-list-item' + (isActive ? ' active' : '') + '" data-index="' + i + '">' +
                '<span class="song-index">' + (i + 1) + '</span>' +
                '<span class="song-name">' + song.title + '</span>' +
                (isActive && this.isPlaying ? '<span class="playing-indicator">▶</span>' : '') +
                '</li>';
            container.append(item);
        }
        
        var self = this;
        $('.music-list-item').off('click').on('click', function() {
            var index = parseInt($(this).data('index'));
            self.loadSong(index);
            self.play();
        });
    };
    
    MusicPlayer.prototype.play = function() {
        if (this.audio && this.audio.src) {
            var self = this;
            this.audio.play().catch(function(error) {
                console.log('播放失败:', error);
            });
        }
    };
    
    MusicPlayer.prototype.pause = function() {
        if (this.audio) {
            this.audio.pause();
        }
    };
    
    MusicPlayer.prototype.togglePlay = function() {
        if (this.isPlaying) {
            this.pause();
        } else {
            this.play();
        }
    };
    
    MusicPlayer.prototype.loadSongById = function(songId) {
        for (var i = 0; i < this.musicList.length; i++) {
            if (this.musicList[i].id === songId) {
                this.loadSong(i);
                this.play();
                return true;
            }
        }
        return false;
    };

    MusicPlayer.prototype.getSongById = function(songId) {
        for (var i = 0; i < this.musicList.length; i++) {
            if (this.musicList[i].id === songId) {
                return this.musicList[i];
            }
        }
        return null;
    };

    MusicPlayer.prototype.toggleDesktopLyrics = function() {
        var $desktopLyrics = $('#desktop-lyrics');
        if ($desktopLyrics.length === 0) {
            return;
        }
        if ($desktopLyrics.hasClass('desktop-lyrics-show')) {
            $desktopLyrics.removeClass('desktop-lyrics-show');
            this.desktopLyricsEnabled = false;
        } else {
            $desktopLyrics.addClass('desktop-lyrics-show');
            this.desktopLyricsEnabled = true;
            this.updateDesktopLyrics();
        }
    };

    MusicPlayer.prototype.updateDesktopLyrics = function() {
        if (!this.desktopLyricsEnabled) return;
        var $line = $('#desktop-lyrics-line');
        if (this.currentLyricIndex >= 0 && this.currentLyricIndex < this.lyrics.length) {
            var text = this.lyrics[this.currentLyricIndex].text;
            if ($line.text() !== text) {
                $line.css('opacity', '0');
                setTimeout(function() {
                    $line.text(text);
                    $line.css('opacity', '1');
                }, 150);
            }
        } else {
            $line.text('');
        }
    };

    MusicPlayer.prototype.prevSong = function() {
        var newIndex = (this.currentSongIndex - 1 + this.musicList.length) % this.musicList.length;
        this.loadSong(newIndex);
        this.play();
    };
    
    MusicPlayer.prototype.nextSong = function() {
        var newIndex = (this.currentSongIndex + 1) % this.musicList.length;
        this.loadSong(newIndex);
        this.play();
    };
    
    return MusicPlayer;
})();

var musicPlayer = null;

function initMusicPlayer() {
    musicPlayer = new MusicPlayer();
}
